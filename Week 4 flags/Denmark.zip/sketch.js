var canW=370 // canvas width
var canH=240 // canvas height

function setup() {
  createCanvas(canW, canH);
background(200,16,46);
}

function draw() {
  var l2Xpos=canW*14/37
stroke(255,255,255)
strokeWeight(canW*4/37)
line(0, canH/2, canW, canH/2)  //horiz line
line(l2Xpos, 0,l2Xpos,canH,) //vert line
}